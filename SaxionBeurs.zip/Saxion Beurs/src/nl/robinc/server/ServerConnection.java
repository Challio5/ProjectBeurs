package nl.robinc.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import javafx.collections.ObservableList;
import nl.robinc.database.dao.AanbiedingDao;
import nl.robinc.database.dao.AandeelDao;
import nl.robinc.database.dao.GebruikerDao;
import nl.robinc.database.dao.VerenigingDao;
import nl.robinc.model.Aanbieding;
import nl.robinc.model.Aandeel;
import nl.robinc.model.Gebruiker;
import nl.robinc.model.Vereniging;
import nl.robinc.request.ActionType;
import nl.robinc.request.ModelType;
import nl.robinc.request.ParameterType;

public class ServerConnection implements Runnable {

	private Socket socket;
	
	private GebruikerDao gebruikerDao;
	private VerenigingDao verenigingDao;
	
	private AandeelDao aandeelDao;
	private AanbiedingDao aanbiedingDao;
	
	public ServerConnection(Socket socket) {
		this.socket = socket;
		
		aandeelDao = new AandeelDao();
		gebruikerDao = new GebruikerDao();
		verenigingDao = new VerenigingDao();
		aanbiedingDao = new AanbiedingDao();
	}
	
	@Override
	public void run() {
		System.out.println("SERVER Verbinding geaccepteerd");
		
		try {
			BufferedReader reader = new BufferedReader(
						new InputStreamReader(
							socket.getInputStream()));
			
			DataOutputStream writer = new DataOutputStream(
										socket.getOutputStream());
		
			
			ModelType dataType = ModelType.valueOf(reader.readLine());
			ActionType actionType = ActionType.valueOf(reader.readLine());
			ParameterType parameterType = ParameterType.valueOf(reader.readLine());
			
			String message = reader.readLine();
			String[] parameters = message.split("\\|");
			
			System.out.println("SERVER Message ontvangen: " + dataType + actionType +
					parameterType + message);

			switch (actionType) {
			case GET:
				switch(parameterType) {
				case NONE:
					ObservableList<Aanbieding> aanbiedingLijst = aanbiedingDao.getAanbieding();
					for(Aanbieding aanbieding : aanbiedingLijst) {
						String reply = this.generateAanbiedingString(aanbieding);
						writer.writeBytes(reply);
					}
					break;
				case GEBRUIKER:
					System.err.println("SERVER Geen gebruiker parameter");
					break;
				case VERENIGING:
					String verenigingsnaam = parameters[0];
					Aanbieding aanbieding = aanbiedingDao.getAanbieding(verenigingsnaam).get(0);
					String reply = this.generateAanbiedingString(aanbieding);
					writer.writeBytes(reply);
					break;
				case AANDEEL:
					System.err.println("SERVER Geen aandeel parameter");
					break;
				case AANBIEDING:
					int gebruikersnummer = Integer.parseInt(parameters[0]);
					Aanbieding aanbieding1 = aanbiedingDao.getAanbieding(gebruikersnummer).get(0);
					String reply1 = this.generateAanbiedingString(aanbieding1);
					writer.writeBytes(reply1);
					break;
				case VERGEN:
					System.err.println("SERVER Geen vereniging/gebruiker parameter");
					break;
				default: 
					System.err.println("SERVER Onbekend parametertype: " + parameterType);
				}
				break;
			
			case ADD:
				Aanbieding aanbieding1 = new Aanbieding(Integer.parseInt(parameters[0]),
						new Gebruiker(Integer.parseInt(parameters[1]), parameters[2], 
								parameters[3], parameters[4], Double.parseDouble(parameters[5])),
						new Vereniging(Integer.parseInt(parameters[6]), parameters[7]),
						Integer.parseInt(parameters[8]),
						Double.parseDouble(parameters[9]));
				aanbiedingDao.addAanbieding(aanbieding1);
			break;
			
			case REMOVE:
				Aanbieding aanbieding2 = new Aanbieding(Integer.parseInt(parameters[0]),
						new Gebruiker(Integer.parseInt(parameters[1]), parameters[2], 
								parameters[3], parameters[4], Double.parseDouble(parameters[5])),
						new Vereniging(Integer.parseInt(parameters[6]), parameters[7]),
						Integer.parseInt(parameters[8]),
						Double.parseDouble(parameters[9]));
				aanbiedingDao.removeAanbieding(aanbieding2);
			break;
			
			default:
				System.out.println("SERVER Onbekend actiontype " + actionType);
			}
			
			reader.close();
			socket.close();
			System.out.println("SERVER Sluit de verbinding");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String generateGebruikerString(Gebruiker gebruiker) {		
		String gebruikerString = "" +
				gebruiker.getPRIMARYKEY() + '|' + 
				gebruiker.getGebruikersnaam() + '|' + 
				gebruiker.getWachtwoord() + '|' + 
				gebruiker.getNaam() + '|' + 
				gebruiker.getBalans();
		
		return gebruikerString;
	}
	
	private String generateVerenigingString(Vereniging vereniging) {
		String verenigingString = "" +
				vereniging.getPRIMARYKEY() + '|' +
				vereniging.getNaam();
		
		return verenigingString;
	}
	
	private String generateAandeelString(Aandeel aandeel) {
		String aandeelString = "" +
				aandeel.getPRIMARYKEY() + '|' +
				this.generateGebruikerString(aandeel.getGebruiker()) + '|' +
				this.generateVerenigingString(aandeel.getVereniging());
		
		return aandeelString;
	}
	
	private String generateAanbiedingString(Aanbieding aanbieding) {
		String aanbiedingString = "" +
				aanbieding.getPRIMARYKEY() + '|' +
				this.generateGebruikerString(aanbieding.getGebruiker()) + '|' +
				this.generateVerenigingString(aanbieding.getVereniging()) + '|' +
				aanbieding.getAantal() + '|' +
				aanbieding.getPrijs();
		
		return aanbiedingString;
	}

}
