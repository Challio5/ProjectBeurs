 package nl.robinc.apl;

import javafx.application.Application;
import javafx.concurrent.WorkerStateEvent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import nl.robinc.client.AanbiedingClient;
import nl.robinc.controller.Controller;
import nl.robinc.request.ActionType;
import nl.robinc.request.ModelType;
import nl.robinc.request.ParameterType;
import nl.robinc.server.Server;
import nl.robinc.view.BeursPane;

public class Beurs extends Application{

	// View
	private BeursPane view;
	private AanbiedingClient client;
	
	public Beurs() {
		view = new BeursPane();
		
		new Controller(view);
	}

	@Override
	public void start(Stage stage) throws Exception {
		Scene scene = new Scene(view);
		stage.setScene(scene);
		stage.setTitle("Beurs");
		stage.show();
		
		Server server = new Server();
		new Thread(server).start();
		
		String[] parameters = {"1"};
		client = new AanbiedingClient(ActionType.GET, ParameterType.AANBIEDING, parameters);
		
		new Thread(client).start();
		client.setOnSucceeded(this::succeed);
		
		//server.close();
	}
	
	public void succeed(WorkerStateEvent event) {
		System.out.println(client.getValue());
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}
