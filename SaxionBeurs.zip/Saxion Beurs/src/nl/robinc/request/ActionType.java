package nl.robinc.request;

public enum ActionType {
	GET,
	ADD,
	REMOVE
}
