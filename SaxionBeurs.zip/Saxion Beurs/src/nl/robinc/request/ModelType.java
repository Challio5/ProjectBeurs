package nl.robinc.request;

public enum ModelType {
	GEBRUIKER,
	VERENIGING,
	AANDEEL,
	AANBIEDING
}
