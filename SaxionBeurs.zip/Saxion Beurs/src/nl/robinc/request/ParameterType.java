package nl.robinc.request;

public enum ParameterType {
	NONE,
	GEBRUIKER,
	VERENIGING,
	AANDEEL,
	AANBIEDING,
	VERGEN
}
